let addStockTargetId = null;

function openAddStock(id){
  const p = arrayFind(DATA.products, function(x){ return x.id === id; });
  addStockTargetId = id;
  document.getElementById('restockLabel').textContent = 'Add stock to "' + p.name + '" (currently ' + getStock(id) + ')';
  document.getElementById('restockQty').value = 10;
  openModal('restockModal');
}

function processAddStock(qty){
  if(!qty || qty < 1){
    showToast('Enter a valid quantity.', true);
    return false;
  }
  const rec = getInventoryRecord(addStockTargetId);
  const p = arrayFind(DATA.products, function(x){ return x.id === addStockTargetId; });
  rec.stock = rec.stock + qty;
  saveData();
  showToast('Added ' + qty + ' to ' + p.name + '.');
  return true;
}

function initAddStockModule(){
  document.getElementById('restockConfirmBtn').addEventListener('click', function(){
    const qty = parseInt(document.getElementById('restockQty').value, 10);
    const ok = processAddStock(qty);
    if(!ok) return;
    closeModal('restockModal');
    renderInventory();
  });
}
