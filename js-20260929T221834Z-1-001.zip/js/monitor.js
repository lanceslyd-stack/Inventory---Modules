let invCategory = 'all';

function filterInventoryItems(query, category){
  const q = query.trim().toLowerCase();
  let items = arrayFilter(DATA.products, function(p){
    return p.name.toLowerCase().indexOf(q) !== -1;
  });

  if(category === 'food' || category === 'game'){
    items = arrayFilter(items, function(p){ return p.category === category; });
  }
  if(category === 'low'){
    items = arrayFilter(items, function(p){ return isLowStock(p.id); });
  }
  return items;
}

function renderInventory(){
  const items = filterInventoryItems(document.getElementById('invSearch').value, invCategory);

  let html = '';
  if(items.length === 0){
    html = '<tr class="empty-row"><td colspan="6">No items match this view.</td></tr>';
  } else {
    for(let i = 0; i < items.length; i++){
      const p = items[i];
      const stock = getStock(p.id);
      const low = isLowStock(p.id);
      const oos = stock <= 0;
      const status = oos ? '<span class="tag limited">Out of stock</span>' :
        low ? '<span class="tag seasonal">Low stock</span>' : '<span class="tag regular">In stock</span>';
      html += '<tr class="' + (low || oos ? 'low-stock' : '') + '">' +
        '<td>' + p.name + '</td>' +
        '<td><span class="tag ' + p.category + '">' + catLabel(p.category) + '</span></td>' +
        '<td>' + fmt(p.price) + '</td>' +
        '<td>' + stock + '</td>' +
        '<td>' + status + '</td>' +
        '<td class="row-actions">' +
        '<button class="btn subtle small" data-addstock="' + p.id + '">Add stock</button>' +
        '<button class="btn ghost small" data-removestock="' + p.id + '">Remove stock</button>' +
        '</td></tr>';
    }
  }
  document.getElementById('invTable').innerHTML = html;

  
  const addButtons = document.querySelectorAll('[data-addstock]');
  for(let i = 0; i < addButtons.length; i++){
    const btn = addButtons[i];
    btn.addEventListener('click', function(){ openAddStock(btn.dataset.addstock); });
  }
  const removeButtons = document.querySelectorAll('[data-removestock]');
  for(let i = 0; i < removeButtons.length; i++){
    const btn = removeButtons[i];
    btn.addEventListener('click', function(){ openRemoveStock(btn.dataset.removestock); });
  }
}

function initMonitorModule(){
  const catTabs = document.getElementById('invCatTabs');
  catTabs.addEventListener('click', function(e){
    const btn = e.target.closest('.pill-tab');
    if(!btn) return;
    invCategory = btn.dataset.cat;
    const tabs = catTabs.querySelectorAll('.pill-tab');
    for(let i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i] === btn);
    renderInventory();
  });

  document.getElementById('invSearch').addEventListener('input', renderInventory);
}
