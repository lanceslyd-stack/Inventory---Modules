let removeStockTargetId = null;

function openRemoveStock(id){
  const p = arrayFind(DATA.products, function(x){ return x.id === id; });
  removeStockTargetId = id;
  document.getElementById('removeStockLabel').textContent = 'Remove stock from "' + p.name + '" (currently ' + getStock(id) + ')';
  document.getElementById('removeStockQty').value = 1;
  openModal('removeStockModal');
}

function processRemoveStock(qty){
  if(!qty || qty < 1){
    showToast('Enter a valid quantity.', true);
    return false;
  }
  const rec = getInventoryRecord(removeStockTargetId);
  const p = arrayFind(DATA.products, function(x){ return x.id === removeStockTargetId; });
  if(qty > rec.stock){
    showToast('Cannot remove more than the ' + rec.stock + ' currently in stock.', true);
    return false;
  }
  rec.stock = rec.stock - qty;
  saveData();
  showToast('Removed ' + qty + ' from ' + p.name + '.');
  return true;
}

function initRemoveStockModule(){
  document.getElementById('removeStockConfirmBtn').addEventListener('click', function(){
    const qty = parseInt(document.getElementById('removeStockQty').value, 10);
    const ok = processRemoveStock(qty);
    if(!ok) return;
    closeModal('removeStockModal');
    renderInventory();
  });
}
